public class Mahasiswa {

	public Mahasiswa(){

	}

	public int nim;
	public String nama;
	public String alamat;
	public String kelas;

	public void tampilBiodata() {
		System.out.println("\nNim\t : "+nim);
		System.out.println("Nama\t : "+nama);
		System.out.println("Alamat\t : "+alamat);
		System.out.println("Kelas\t : "+kelas);
	}

}