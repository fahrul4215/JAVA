public class Game {
	public int idGame;
	public String judulGame;
	public int harga;
	
	public void tampilGame() {
		System.out.println("ID\t : "+idGame);
		System.out.println("Judul\t : "+judulGame);
		System.out.println("Harga\t : "+harga);
	}
}