public class Member {
	public int idMember;
	public String namaMember;
	public String alamat;
	
	public void tampilMember() {
		System.out.println("ID\t : "+idMember);
		System.out.println("Nama\t : "+namaMember);
		System.out.println("Alamat\t : "+alamat);
	}
}