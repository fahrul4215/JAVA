class MobilTest {
	public static void main(String[] args) {
		Mobil mbl = new Mobil();

		mbl.tampilkanStatus();

		mbl.tambahKecepatan();

		mbl.nyalakanMesin();
		mbl.tampilkanStatus();

		mbl.tambahKecepatan();
		mbl.tampilkanStatus();

		mbl.tambahKecepatan();
		mbl.tampilkanStatus();

		mbl.tambahKecepatan();
		mbl.tampilkanStatus();		
	}
}