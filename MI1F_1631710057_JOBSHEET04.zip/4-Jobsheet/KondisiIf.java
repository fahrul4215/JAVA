class KondisiIf {
	public static void main(String[] args) {
		int a = 10, b = 12, c = 20;

		if (a<b && c>a) {
			System.out.println("Bilangan "+a+", Lebih kecil dari "+b);
		} else {
			System.out.println("Bilangan "+a+", Lebih besar dari "+b);
		}
	}
}