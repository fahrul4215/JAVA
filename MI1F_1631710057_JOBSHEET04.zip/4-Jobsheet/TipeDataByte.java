class TipeDataByte {
	public static void main(String[] args) {
		byte bilangan1 = 10;
		byte bilangan2 = 15;

		System.out.println("Nilai Bilangan 1 = "+bilangan1);
		System.out.println("Nilai Bilangan 2 = "+bilangan2);
	}
}