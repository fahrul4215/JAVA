class TipeBoolean {
	public static void main(String[] args) {
		boolean dataB;

		dataB = false;

		if (dataB) {
			// Statement1 ini akan ditampilkan jika nilai dataB adalah true
			System.out.println("data B bernilai "+dataB);
		}else {
			// Statement2 ini akan ditampilkan jika nilai dataB adalah false
			System.out.println("data B bernilai "+dataB);
		}
	}
}