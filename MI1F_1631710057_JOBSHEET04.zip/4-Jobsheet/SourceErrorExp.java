class SourceErrorExp {
	public static void main(String[] args) {
		System.out.println("awal program");

		int x = 10;

		x = x / 2;

		System.out.println(x);
		System.out.println("akhir program");
	}
}