class StatementSwitch {
	public static void main(String[] args) {
		for (int i=0;i<1;i++ ) {
			switch (i) {
				case 0:
					System.out.println("Nilai dari i adalah 0");
					break;
				case 1:
					System.out.println("Nilai dari i adalah 1");
					break;
				default :
					System.out.println("Nilai dari i lebih dari 1");
			}
		}
	}
}